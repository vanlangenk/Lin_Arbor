# Lynn Arbor NDVI Labeling Project
This project generates a web-based interactive NDVI map with plant species labels.
