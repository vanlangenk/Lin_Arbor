from PIL import Image
import os

tiff_path = os.path.join('data', 'Linwood-Arboretum-4-13-2025-orthophoto.tif')
png_path = os.path.join('docs', 'ndvi_map.png')

img = Image.open(tiff_path)
img.save(png_path, format='PNG')
print(f"Converted {tiff_path} to {png_path}")
